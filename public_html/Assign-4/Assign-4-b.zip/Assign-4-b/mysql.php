<?php
$config = parse_ini_file('/home/amanzer/private/config.ini');
$resid=MySQLi_Connect($config['servername'],$config['username'],$config['password'],$config['dbname']);
//skhpa@yahoo.com
?>
