<?php

$res_id=MySQLi_Connect('localhost','amanzer','','amanzer');
					if(MySQLi_Connect_Errno()) {
						echo "<tr align='center'> <td colspan='5'> Failed to connect to MySQL </td> </tr>";
					}
					else {
					}

?>
