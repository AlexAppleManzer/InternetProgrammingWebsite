<?php
function getDatabaseConnection() {
    return MySQLi_Connect('localhost','amanzer','','amanzer');
}

?>